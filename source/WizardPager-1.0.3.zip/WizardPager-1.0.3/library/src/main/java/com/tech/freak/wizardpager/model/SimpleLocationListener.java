package com.tech.freak.wizardpager.model;

import android.location.Location;

public interface SimpleLocationListener {
	public void onLocationChanged(Location location);
}